/**
 * File: headers.h
 * Author: KaspeDKK - <https://github.com/kaspedkk>
 * 
 * Description: Main Header file
 */

#include "colors.h"